create an editor in an html page and vanilla javascript with classes to compose a workflow. It as a canvas to compose the panel, a toolbox from which drag & drop flow steps. Flow steps can be placed, named, coloured, add property, resized, and also have a script that handles the input value to generate an output value. Steps can be connected with inputs and outputs with pipes. A pipe connects a step output to a step input.  And generate the javascript code to load an save a specific panel

        1. The main Flow Editor class
        2. Step class for different UI elements 
        3. All event handlers for mouse/keyboard interactions
        4. Property panels and dialogs
        5. Undo/redo functionality
        6. Import/export capabilities
